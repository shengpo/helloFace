import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.video.*; 
import monclubelec.javacvPro.*; 
import controlP5.*; 
import oscP5.*; 
import netP5.*; 
import java.awt.*; 
import java.io.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class helloFace extends PApplet {

/***********************
 helloFace
 =======
 helloFace is a face-detection tool which aims on simple setting and easy using.
 
 Functions:
 ---------------
 * using OSC to send out the result of face-detection
 * also receive OSC message for dynamic settings
 * providing GUI for simple setting and easy using
 
 Instruction:
 ----------------
 * \u6309s/S\u9375, \u53ef\u4ee5switch on/off \u8a2d\u5b9a\u9762\u677f
 * \u6309i/I\u9375, \u53ef\u4ee5switch on/off \u8cc7\u8a0a\u9762\u677f
 * \u6309v/V, \u53ef\u4ee5switch on/off \u5075\u6e2c\u5230\u7684\u8996\u89ba\u8cc7\u8a0a
 
 
 Used libraries:
 ---------------------
 * Processing Video library (version: 2.0b7)
 * oscP5 (version: 0.9.8)
 * controlP5 (version: 2.0.4)
 * javacvPro (version: 0.5)
 
 
 Author: 
 -----------
 Shen, Sheng-Po (http://shengpo.github.com)
 
 License: 
 ------------
 CC BY-SA 3.0
 
 ***********************/










//for view panel
int viewPanelWidth = 400;
int viewPanelHeight = 300;

//for setting panel
SettingPanel settingPanel = null;
int settingPanelWidth = 400;

//for info panel
InfoPanel infoPanel = null;

//for camera
Capture cam = null;
CamProperties camProperties = null;

//for detector
Detector detector = null;

//for OSC handler
OSCHandler oscHandler = null;

//for initializer
Initializer initializer = null;

//for font (used in InfoPanel, SettingPanel)
PFont infoFont = null;
int fontSize = 12;

//for garbage collector
GarbageCollector gc = null;
float gcPeriodMinute = 5;    //\u8a2d\u5b9a\u5e7e\u5206\u9418\u505a\u4e00\u6b21gc





public void setup() {
    size(viewPanelWidth, viewPanelHeight);
    background(0);
    frame.setResizable(true);    //make frame is resizable
    
    //set universal font in this application
    infoFont = createFont("Georgia", fontSize);
    textFont(infoFont);
    
    //for camera properties
    camProperties = new CamProperties();

    //for setting panel
    settingPanel = new SettingPanel(this, settingPanelWidth);
    
    //for info panel
    infoPanel = new InfoPanel(viewPanelWidth);
    
    //for Initializer
    initializer = new Initializer();
    initializer.loadDefaultSetting();

    //for garbage collector
    gc = new GarbageCollector(gcPeriodMinute);
    gc.start();
}


public void draw() {
    background(0);

    //read-in camera video
    if (cam!=null && cam.available()) {
        cam.read();
    }

    //do detecting
    if(detector != null){
        //\u5c07detect\u7684\u7d50\u679c\u79c0\u51fa\u4f86
        showImage(detector.doDetect(cam));
    }else{
        //\u76f4\u63a5\u79c0camera\u5f71\u50cf\uff0c\u4e0d\u505adetect
        showImage(cam);
    }
    
    //show verbose info
    infoPanel.show();
}


public void showImage(PImage img){
    if(img != null){
        //resize() has a bug in Processing2.0b7
        //img.resize(viewPanelWidth, 0); 
        //image(img, 0, (viewPanelHeight-img.height)/2);
        
        float w = viewPanelWidth;
        float h = img.height*(viewPanelWidth/PApplet.parseFloat(img.width));
        float x = 0;
        float y = (viewPanelHeight-h)/2;
        
        image(img, x, y, w, h);
    }
}


public void keyPressed(){
    //switch on/off setting panel
    if(key=='s' || key=='S'){
        if(settingPanel != null)    settingPanel.switchOnOff();
    }

    //switch on/off info panel
    if(key=='i' || key=='I'){
        if(infoPanel != null)    infoPanel.switchOnOff();
    }

    //switch on/off detecting-visual-info    
    if(key=='v' || key=='V'){
        if(detector != null)    detector.switchOnOffVisualInfo();
    }
}
public class CamProperties {
    private String[] cameras = null;            //\u7d00\u9304\u53ef\u4f7f\u7528\u7684camera\u5217\u8868    
    private String selectedCamera = "";     //\u7d00\u9304\u88ab\u9078\u53d6\u7684camera\u53c3\u6578\u8a2d\u5b9a
    
    //camera\u53c3\u6578\u9805\u76ee
    private String camName = "";              //camera\u7684\u540d\u5b57
    private int camWidth = 0;                    //width of camera's resolution
    private int camHeight = 0;                  //height of camera's resolution
    private int fps = 0;                            //fps of camera
    
    
    
    public CamProperties(){
        //get available cameras
        cameras = Capture.list();
    }
    
    public String[] getAvailableList(){
        if (cameras.length == 0) {
            println("[INFO] There are no cameras available for capture.");
            return null;
        } else {
            println("[INFO] Available cameras:");
            println("-----------------------------");
            for (int i = 0; i < cameras.length; i++) {
                println(cameras[i]);
            }
            println("-----------------------------");
            return cameras;
        }      
    }
    
    public void setCamera(String selectedCamera){
        this.selectedCamera = selectedCamera;

        //get related properties of selected camera
        String[] params = split(selectedCamera, ",");
        for(int i=0; i<params.length; i++){
            if(trim(params[i]).startsWith("name=")){
                camName = trim(params[i]).substring(5);    //retrieve substring from index 5 (after "name=")
            }
            if(trim(params[i]).startsWith("size=")){
                String[] resolution = split(trim(params[i]).substring(5), "x");    //retrieve substring from index 5 (after "size=")
                camWidth = PApplet.parseInt(resolution[0]);
                camHeight = PApplet.parseInt(resolution[1]);
            }
            if(trim(params[i]).startsWith("fps=")){
                fps = PApplet.parseInt(trim(params[i]).substring(4));    //retrieve substring from index 4 (after "fps=")
            }
        }
        
        println("[INFO] selected camera parameter's items: ");
        println("camera name : " + camName);
        println("camera resolution : " + camWidth + " x " + camHeight);
        println("camera fps : " + fps);
    }
    
    
    public String getSelectedCamera(){
        return selectedCamera;
    }
    
    public String getCamName(){
        return camName;
    }
    
    public int getCamWidth(){
        return camWidth;
    }
    
    public int getCamHeight(){
        return camHeight;
    }
    
    public int getCamFPS(){
        return fps;
    }
}
//for any controller event of controlP5
/*for controller event test
void controlEvent(ControlEvent theEvent) {
    if (theEvent.isGroup()) {
        // check if the Event was triggered from a ControlGroup
        println("event from group : "+theEvent.getGroup().getValue()+" from "+theEvent.getGroup());
    } else if (theEvent.isController()) {
        println("event from controller : "+theEvent.getController().getValue()+" from "+theEvent.getController());
    }
}
*/

public void controlEvent(ControlEvent theEvent) {
    //Toggle: setAsDefaultToggle
    if(theEvent.getName().equals("setAsDefaultToggle")){
        boolean isSetAsDefault = false;
        isSetAsDefault = PApplet.parseBoolean(PApplet.parseInt(theEvent.getController().getValue()));

        //\u5132\u5b58\u76ee\u524d\u8a2d\u5b9a\u503c
        if(isSetAsDefault){
            if(initializer.isDone()){    //initializer\u904b\u4f5c\u5b8c\u5f8c\uff0c\u4e4b\u5f8c\u66f4\u8a72\u7684\u8a2d\u5b9a\u624d\u505asnapshot
                //save snapshot of controllers as default settings
                settingPanel.getControlP5().getProperties().setSnapshot("settings");    //\u5c07\u76ee\u524d\u7684controllers' properties\u5b58\u5230RAM\u4e2d
                settingPanel.getControlP5().getProperties().saveSnapshotAs(dataPath("defaultSettings"), "settings");    //\u5c07RAM\u4e2d\u8a18\u61b6\u7684controllers' properties\u5b58\u5230\u6a94\u6848\u4e2d(settings.ser\u6a94)
                
                //for hack (\u89e3\u6c7aconnectToggle\u6bd4OSc-related TextField\u8f09\u5165\u5feb\u901f\u7684\u554f\u984c(\u5c0e\u81f4\u7121\u6cd5\u9806\u5229\u5efa\u7acbOSC connection))
                if(settingPanel.getControlP5().get(Toggle.class, "connectToggle").getState() == true){
                    String[] state = {"1"};
                    saveStrings(dataPath("")+"/connectToggleState.hack", state);
                }else{
                    String[] state = {"0"};
                    saveStrings(dataPath("")+"/connectToggleState.hack", state);
                }
                
                println("[INFO] current controllers' state are used as default settings");

                //change deleteDefaultSettingFileBang caption label
                settingPanel.getControlP5().get(Bang.class, "deleteDefaultSettingFileBang").setCaptionLabel("Delete    Default    Setting    Files");
            }
        }
    }
    
    //DropdownList: cameraDropdownList
    if(theEvent.getName().equals("cameraDropdownList")){
        String[] camlist = camProperties.getAvailableList();
        if(camlist != null){
            if(cam != null)    cam.stop();    //\u5148\u505c\u6b62\u4e4b\u524d\u9078\u64c7\u7684camera
            camProperties.setCamera(camlist[(int)theEvent.getValue()]);    //\u8a2d\u5b9a\u76ee\u524d\u9078\u7684camera parameters (\u7d00\u9304parameter\u4e2d\u7684\u5404\u500b\u9805\u76ee)
            cam = new Capture(this, camProperties.getSelectedCamera());    //\u7522\u751f\u65b0\u7684camera
            cam.start();    //\u555f\u52d5
            println("[INFO] camera initialized !");
            
            //for detector
            detector = null;    //\u6e05\u9664\u4e4b\u524d\u7684detector
            detector = new Detector(this, camProperties.getCamWidth(), camProperties.getCamHeight(), detector.FACEDETECTION);    //\u8a2d\u5b9a\u505aface detection
            println("[INFO] detector initialized !");
            
            //\u53ea\u8981\u66f4\u52d5\u904e\uff0c\u5c31\u5c07setAsDefaultToggle\u8a2d\u6210false
            if(initializer.isDone()){
                settingPanel.getControlP5().get(Toggle.class, "setAsDefaultToggle").setValue(false);
            }
        }
    }

    //Toggle: connectToggle
    if(theEvent.getName().equals("connectToggle")){
        boolean isBuildConnect = false;
        isBuildConnect = PApplet.parseBoolean(PApplet.parseInt(theEvent.getController().getValue()));
        if(!isBuildConnect){
            //change connectToggle caption label
            theEvent.getController().setCaptionLabel("Click    to    build    OSC    connection");
            //change osc connection info
            settingPanel.getControlP5().get(Textfield.class, "oscConnectionInfoTextfield").setCaptionLabel("Waiting    for     new    OSC    connection");
            //unlock all OSC-related TextField
            settingPanel.getControlP5().get(Textfield.class, "localOscPortTextfield").setLock(false).setColorBackground(color(60));
            settingPanel.getControlP5().get(Textfield.class, "remoteAddressTextfield").setLock(false).setColorBackground(color(60));
            settingPanel.getControlP5().get(Textfield.class, "remoteOscPortTextfield").setLock(false).setColorBackground(color(60));
            return;    //connectToggle\u503c\u70bafalse\u5247return\u4e0d\u7e7c\u7e8c
        }

        int localOscPort = PApplet.parseInt(settingPanel.getControlP5().get(Textfield.class, "localOscPortTextfield").getText());
        String remoteAddress = settingPanel.getControlP5().get(Textfield.class, "remoteAddressTextfield").getText();
        int remoteOscPort =  PApplet.parseInt(settingPanel.getControlP5().get(Textfield.class, "remoteOscPortTextfield").getText());
        
        println("[INO] localOscPort: "+localOscPort);
        println("[INO] remoteAddress: "+remoteAddress);
        println("[INO] remoteOscPort: "+remoteOscPort);
        
        if(localOscPort>0 && !remoteAddress.equals("") && remoteOscPort>0){
            //for OSC handler
            if(oscHandler != null){    //\u6e05\u9664\u4e4b\u524d\u7684oscHandler
                oscHandler.stop();
                oscHandler = null;    
            }
            oscHandler = new OSCHandler(this, localOscPort, remoteAddress, remoteOscPort);
            println("[INFO]  OSC Handler is intialized !");
            
            //set connectToggle caption label
            theEvent.getController().setCaptionLabel("Click    Me    for    New    OSC    Connection");
            
            //set osc connection info
            settingPanel.getControlP5().get(Textfield.class, "oscConnectionInfoTextfield").setCaptionLabel("OSC    connection    OK");

            //lock all OSC-related TextField
            settingPanel.getControlP5().get(Textfield.class, "localOscPortTextfield").setLock(true).setColorBackground(color(120));
            settingPanel.getControlP5().get(Textfield.class, "remoteAddressTextfield").setLock(true).setColorBackground(color(120));
            settingPanel.getControlP5().get(Textfield.class, "remoteOscPortTextfield").setLock(true).setColorBackground(color(120));
    
            //\u53ea\u8981\u66f4\u52d5\u904e\uff0c\u5c31\u5c07setAsDefaultToggle\u8a2d\u6210false
            if(initializer.isDone()){
                settingPanel.getControlP5().get(Toggle.class, "setAsDefaultToggle").setValue(false);
            }
        }else{
            println("[INFO]  OSC related parameters could be wrong, please check it again");

            //reset to false for being pressed at next time
            theEvent.getController().setValue(0);    

            //set osc connection info
            settingPanel.getControlP5().get(Textfield.class, "oscConnectionInfoTextfield").setCaptionLabel("OSC    paramteres    could    be    wrong,    please    check");
        }
    }
        
    //Bang: deleteDefaultSettingFileBang
    if(theEvent.getName().equals("deleteDefaultSettingFileBang")){
        int deleteCount = 0;
        
        //delete default setting files: data\u8cc7\u6599\u593e\u4e0b\u7684defaultSettings.ser\u6a94 \u548c connectToggleState.hack\u6a94
        File settingFile1 = new File(dataPath("")+"/defaultSettings.ser");
        if(settingFile1.delete() == true){
            println("[INFO] default setting file (defaultSettings.ser) is deleted");
            deleteCount = deleteCount + 1;
        }else{
            println("[INFO] default setting file (defaultSettings.ser) can not be deleted. It could be not existed or permission issue");
        }

        File settingFile2 = new File(dataPath("")+"/connectToggleState.hack");
        if(settingFile2.delete() == true){
            println("[INFO] default setting file (connectToggleState.hack) is deleted");
            deleteCount = deleteCount + 1;
        }else{
            println("[INFO] default setting file (connectToggleState.hack) can not be deleted. It could be not existed or permission issue");
        }

        if(deleteCount == 2){
            //change deleteDefaultSettingFileBang caption label
            theEvent.getController().setCaptionLabel("No    Default    Setting    Files");            
            //\u5c07setAsDefaultToggle\u8a2d\u6210false
            settingPanel.getControlP5().get(Toggle.class, "setAsDefaultToggle").setValue(false);
        }
    }
}

public class Detector {
    //for detection type
    static final public int FACEDETECTION = 0;    //face detection
    
    private PApplet papplet = null;
    private PGraphics curImage  = null;    //\u76ee\u524d\u6b63\u8981\u88ab\u8655\u7406\u7684image (from camera)  
    private boolean isShowVisualInfo = true;
    
    //opencv
    private OpenCV opencv = null;
    private int detectionType = -1;
    
    //face detection
    private Rectangle[] faceRect = null;    //recording detected faces 
    
    
    
    public Detector(PApplet papplet, int imageWidth, int imageHeight, int detectionType){
        this.papplet = papplet;
        this.detectionType = detectionType;
        curImage = createGraphics(imageWidth, imageHeight);
        
        //initializing OpenCV
        opencv = new OpenCV(papplet);
        opencv.allocate(imageWidth, imageHeight);
        
        //cascade setting
        switch(detectionType){
            case FACEDETECTION:    //for face detection
                        opencv.cascade(dataPath("cascade"),"haarcascade_frontalface_alt.xml");
                        break;
            default:    //\u4e0d\u662f\u76ee\u524d\u6709\u63d0\u4f9b\u7684detecting\u529f\u80fd
                        detectionType = -1;
                        break;
        }
    }
    
    public PImage doDetect(PImage img){
        if(img==null || img.width<=0 || img.height<=0) return null;    //\u907f\u514d\u8655\u7406null image\u6216empty image
        
        //copy image for further detections
        opencv.copy(img);

        /*do detecting*/
        switch(detectionType){
            case FACEDETECTION:    //face detection
                        //opencv.cascade(dataPath("cascade"),"haarcascade_frontalface_alt.xml");
                        faceRect = opencv.detect(true);
                        break;
            case 1:
                        //other detectiing function will be added in the future
                        break;
            default:
                        //do nothing ...
                        break;
        }
                
        //send out OSC messages
        if(oscHandler != null)    oscHandler.sendOut(faceRect);
         
        //show final result with/out visual info
        if(isShowVisualInfo){
            curImage.beginDraw();
            //curImage.image(img, 0, 0);    //put original image first
            curImage.set(0, 0, img);    //put original image first; set() is more faster
            showVisualInfo(curImage);    //add visual info messages on original image
            curImage.endDraw();

            return curImage;
        }else{
            return img;
        }
    }
    
    private void showVisualInfo(PGraphics curImage){
        switch(detectionType){
            case FACEDETECTION:
                        //show\u51fa\u8fa8\u8b58\u5230\u7684\u4eba\u81c9\u77e9\u578b\u7bc4\u570d
                        curImage.noFill();
                        curImage.stroke(255, 0, 0);
                        for(int i=0; i<faceRect.length; i++){
                            curImage.rect(faceRect[i].x, faceRect[i].y, faceRect[i].width, faceRect[i].height);
                        }
            default:
                        //do nothing
                        break;
        }
    }
    
    
    public void switchOnOffVisualInfo(){
        isShowVisualInfo = !isShowVisualInfo;
    }
    
    public String getDetectionTypeName(){
        String typename = "";
        
        switch(detectionType){
            case FACEDETECTION:
                            typename = "FACEDETECTION";
                            break;
            default:
                            typename = "NOT-DEFINED";
                            break;
        }
        
        return typename;
    }
}
public class GarbageCollector extends Thread {
    private int start = 0;                        //in milliseconds
    private float periodMinute = 5;        //do the garbage collection on every period    (in minutes)
    private Runtime runtime = null;

    public GarbageCollector(float periodMinute) {
        start = millis();
        this.periodMinute = periodMinute;
        // get an instance of java.lang.Runtime, force garbage collection  
        runtime=java.lang.Runtime.getRuntime();
    }

    public void run() {
        while(true){
            if( (millis()-start) > periodMinute*60*1000 ){
                start = millis();
                runtime.gc();  
                println("--> run the java garbage collection");
            }
        }
    }
}

public class InfoPanel {
    private int width = 100;    //width of info panel
    private boolean isShowInfo = false;

    
    public InfoPanel(int width){
        this.width = width;
    }
    
    public void show(){
        if(isShowInfo){
            //background of info panel
            noStroke();
            fill(170, 170, 250, 128);
            float h = fontSize*4.5f;
            rect(0, viewPanelHeight-h, width, h);
            
            /*list infos*/
            fill(255, 255, 0);
            //local OSC port
            text("[ Local OSC port ] " + (oscHandler!=null ? oscHandler.getLocalOscPort() : ""), 10, viewPanelHeight-fontSize*3.3f);
            //remote address and OSC port
            text("[ Remote ] " + (oscHandler!=null ? oscHandler.getRemoteAddress() : "") + ":" + (oscHandler!=null ? oscHandler.getRemoteOscPort() : ""), 10, viewPanelHeight-fontSize*2.3f);
            //detecting type
            text("[ Detecting Type ] " + (detector!=null ? detector.getDetectionTypeName() : ""), 10, viewPanelHeight-fontSize*1.3f);
            //selected camera params
            text("[ Cam ] "+camProperties.getSelectedCamera(), 10, viewPanelHeight-fontSize*0.3f);
        }
    }
    
    public void switchOnOff(){
        isShowInfo = !isShowInfo;
    }
}
public class Initializer {
    private boolean isDone = false;    //\u5224\u65b7\u662f\u5426\u8f09\u5165default\u8a2d\u5b9a\u5b8c\u7562
    
    
    public Initializer(){
    }
    
    public void loadDefaultSetting(){
        //load default controllers' state
        boolean isValidFile = settingPanel.getControlP5().getProperties().load(dataPath("")+"/defaultSettings.ser");

        //for hack (\u89e3\u6c7aconnectToggle\u6bd4OSc-related TextField\u8f09\u5165\u5feb\u901f\u7684\u554f\u984c(\u5c0e\u81f4\u7121\u6cd5\u9806\u5229\u5efa\u7acbOSC connection))
        String[] state = loadStrings(dataPath("")+"/connectToggleState.hack");
        if(state != null){
            if(PApplet.parseInt(trim(state[0])) == 1)    settingPanel.getControlP5().get(Toggle.class, "connectToggle").setState(true);  
        }
        
        if(isValidFile && state!=null){
            println("[INFO] initiallized successfully !");
            
            //change deleteDefaultSettingFileBang caption label
            settingPanel.getControlP5().get(Bang.class, "deleteDefaultSettingFileBang").setCaptionLabel("Delete    Default    Setting    Files");
        }
        if(!isValidFile){
            println("[INFO] default setting file (defaultSettings.ser) is not existed");
        }
        if(state == null){
            println("[INFO] default setting file (connectToggleState.hack) is not existed");
        }

        isDone = true;    //\u8868\u793ainitializing\u5b8c\u6210\uff0c\u8b93\u4e4b\u5f8c\u7684controller state\u6539\u8b8a\u6642\u80fd\u5920\u5b58\u53d6\u6700\u65b0\u7684\u6539\u8b8a
    }
    
    public void deleteDefaultSetting(){
        //...
    }

    public boolean isDone(){
        return isDone;
    }
}
public class OSCHandler {
    private PApplet papplet = null;
    private OscP5 oscP5 = null;
    private int localOscPort = 12000;
    private NetAddress myRemoteLocation = null;
    private String remoteAddress = "127.0.0.1";    //default address is local
    private int remoteOscPort = 12001;



    public OSCHandler(PApplet papplet, int localOscPort, String remoteAddress, int remoteOscPort){
        this.papplet = papplet;
        this.localOscPort = localOscPort;
        this.remoteAddress = remoteAddress;
        this.remoteOscPort = remoteOscPort;
        
        oscP5 = new OscP5(papplet, localOscPort);
        myRemoteLocation = new NetAddress(remoteAddress, remoteOscPort);
        
        //add plugs (plug to this object's function!) for receive OSC message from outside
        oscP5.plug(this, "test", "/test");
    }
    

    //this function can be extended for send out other detecting results
    public void sendOut(Rectangle[] faceRect){
        //send out face-detecting result
        if(faceRect!=null && faceRect.length>0){
            OscMessage myMessage = new OscMessage("/faceDetect");
            myMessage.add(faceRect.length);    //\u5075\u6e2c\u5230\u7684face\u6578\u91cf
            
            //\u96c6\u5408\u5075\u6e2c\u5230\u7684\u4eba\u81c9\u8cc7\u8a0a
            String facelist = "";
            for(int i=0; i<faceRect.length; i++){
                facelist = facelist + "x=" +faceRect[i].x + ",y=" + faceRect[i].y + ",w=" + faceRect[i].width + ",h=" + faceRect[i].height;
                if(i < faceRect.length-1){
                    facelist = facelist + "|";
                }
            }
            
            myMessage.add(facelist);    //\u5075\u6e2c\u5230\u7684face\u77e9\u578b\u6578\u64da\u4e32
            oscP5.send(myMessage, myRemoteLocation); 
        }
    }
    
    
    public int getLocalOscPort(){
        return localOscPort;
    }
    public String getRemoteAddress(){
        return remoteAddress;
    }
    public int getRemoteOscPort(){
        return remoteOscPort;
    }
    
    //stop oscP5 and close open Sockets.    (\u907f\u514d\u91cd\u555foscP5\u6642\u4f54\u7528\u76f8\u540c\u7684local port)
    public void stop(){
        if(oscP5 != null)    oscP5.stop();
    }
    

    public void test(int theA, int theB) {
        println("### plug event method. received a message /test.");
        println(" 2 ints received: "+theA+", "+theB);  
    }
}
public class SettingPanel {
    private PApplet papplet = null;
    private int width = 100;            //width of panel
    private boolean isSettingMode = false;
    
    //controlP5 controllers
    private ControlP5 cp5;
    private DropdownList dropdownList;
    

    
    public SettingPanel(PApplet papplet, int width){
        this.papplet = papplet;
        this.width = width;
        
        //controllers
        cp5 = new ControlP5(papplet);
        setControllersLayout();
    }
    
    public void switchOnOff(){
        //\u5c55\u958bsetting panel
        if(!isSettingMode){
            papplet.frame.setSize(viewPanelWidth+width, viewPanelHeight);
            isSettingMode = true;
        }else{    //\u7e2e\u56desetting panel
            papplet.frame.setSize(viewPanelWidth, viewPanelHeight);
            isSettingMode = false;
        }
    }
    
    
    private void setControllersLayout(){
        /*TextFiled for camera params info*/
        cp5.addTextfield("cameraSelectTextfield")
             .setCaptionLabel("Select    Camera :")
             .setPosition(viewPanelWidth+50, 10)
             .setSize(330, 15)
             .setColorForeground(color(0))
             .setColorBackground(color(0))
             .setColorCaptionLabel(color(200))
             .setFont(infoFont)
             .setLock(true)
             .getCaptionLabel().align(ControlP5.LEFT, ControlP5.CENTER);
        
        /*DropdownList for camera list*/
        dropdownList = cp5.addDropdownList("cameraDropdownList")
                               .setSize(330, 100)
                               .setPosition(viewPanelWidth+50, 50)
                               .setBackgroundColor(color(190))
                               .setColorBackground(color(60))
                               .setColorActive(color(255, 128))
                               .setItemHeight(25)
                               .setBarHeight(20)
                               .setScrollbarWidth(10);
        dropdownList.captionLabel().set("camera list");
        dropdownList.captionLabel().style().marginTop = 5;
        dropdownList.captionLabel().style().marginLeft = 5;
        dropdownList.valueLabel().style().marginTop = 5;
        //add camera list items
        String[] cams = camProperties.getAvailableList();
        if(cams != null){
            for(int i=0; i<cams.length; i++){
                dropdownList.addItem(cams[i], i);
            }
        }
        
        /*TextFiled for local OSC port setting*/
        cp5.addTextfield("localOscPortTextfield")
             .setCaptionLabel("local OSC port")
             .setPosition(viewPanelWidth+50, 150)
             .setSize(65, 15)
             .setColorBackground(color(60))
             .setInputFilter(Textfield.INTEGER)
             .setFont(infoFont)
             .setAutoClear(false);
        
        /*TextFiled for remote address setting*/
        cp5.addTextfield("remoteAddressTextfield")
             .setCaptionLabel("remote address")
             .setPosition(viewPanelWidth+200, 150)
             .setSize(110, 15)
             .setColorBackground(color(60))
             .setFont(infoFont)
             .setAutoClear(false);

        /*TextFiled for remote OSC port setting*/
        cp5.addTextfield("remoteOscPortTextfield")
             .setCaptionLabel("remote OSC port")
             .setPosition(viewPanelWidth+315, 150)
             .setSize(65, 15)
             .setColorBackground(color(60))
             .setInputFilter(Textfield.INTEGER)
             .setFont(infoFont)
             .setAutoClear(false);
        
        /*Bang for build OSC connection*/
        cp5.addToggle("connectToggle")
             .setCaptionLabel("Click    to    build    OSC    connection")
             .setPosition(viewPanelWidth+50, 185)
             .setSize(330, 20)
             .setColorForeground(color(120, 135, 170))
             .setColorBackground(color(100))
             .setColorActive(color(150, 150, 170))
             .getCaptionLabel().align(ControlP5.CENTER, ControlP5.CENTER);
             
        /*TextFiled for osc connection info*/
        cp5.addTextfield("oscConnectionInfoTextfield")
             .setCaptionLabel("OSC    connection    not    build")
             .setPosition(viewPanelWidth+50, 210)
             .setSize(330, 15)
             .setColorForeground(color(100))
             .setColorBackground(color(0))
             .setColorCaptionLabel(color(200, 0, 0))
             .setFont(infoFont)
             .setLock(true)
             .getCaptionLabel().align(ControlP5.CENTER, ControlP5.CENTER);

        /*TextFiled for setAsDefaultToggle info*/
        cp5.addTextfield("setAsDefaultToggleInfoTextfield")
             .setCaptionLabel("Set    Above    Setting    As    Default")
             .setPosition(viewPanelWidth+50, 275)
             .setSize(290, 20)
             .setColorForeground(color(60))
             .setColorBackground(color(0))
             .setColorCaptionLabel(color(200))
             .setFont(infoFont)
             .setLock(true)
             .getCaptionLabel().align(ControlP5.CENTER, ControlP5.CENTER);

        /*Toggle for using current controllers' properties to boot helloFace application at next time*/
        cp5.addToggle("setAsDefaultToggle")
             .setCaptionLabel("YES        NO")
             .setPosition(viewPanelWidth+340, 275)
             .setSize(60, 20)
             .setColorBackground(color(60))
             .setColorActive(color(0, 200, 0))
             .setMode(ControlP5.SWITCH)
             .getCaptionLabel().align(ControlP5.CENTER, ControlP5.CENTER);

        /*Bang: deleteDefaultSettingFileBang*/  //ps. Bang\u5728\u505acontroller snapshop\u6642\u6703\u88ab\u5ffd\u7565\u6389
        cp5.addBang("deleteDefaultSettingFileBang")
         .setCaptionLabel("No    Default    Setting    Files")
         .setPosition(viewPanelWidth+250, 0)
         .setSize(150, 15)
         .setColorForeground(color(80, 0, 0))
         .setColorActive(color(200, 0, 0))
         .getCaptionLabel().align(ControlP5.CENTER, ControlP5.CENTER);
    }
    
    
    public ControlP5 getControlP5(){
        return cp5;
    }
}
    static public void main(String[] passedArgs) {
        String[] appletArgs = new String[] { "helloFace" };
        if (passedArgs != null) {
          PApplet.main(concat(appletArgs, passedArgs));
        } else {
          PApplet.main(appletArgs);
        }
    }
}
